<!-- it's a footer section -->
<div class="container-fluid footer my-5">
<div class="card-deck">

  <div class="card">
    <div class="card-body">
      <h5 class="card-title">Album</h5>
      <p class="card-text">
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        <a href="#">English</a> |
        
       
        </p>
    </div>   
  </div>


  <div class="card">
    <div class="card-body">
      <h5 class="card-title">Artists</h5>
      <p class="card-text">
        <a href="#">Arijit singh</a> |   
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |
        <a href="#">Arijit singh</a> |

        </p>
    </div>   
  </div>

  <div class="card">
    <div class="card-body">
      <h5 class="card-title">Generics</h5>
      <p class="card-text">
        <a href="#">Bollywood songs</a> |
        <a href="#">Bollywood songs</a> |
        <a href="#">Bollywood songs</a> |
        <a href="#">Bollywood songs</a> |
        <a href="#">Bollywood songs</a> |
        <a href="#">Bollywood songs</a> |
        <a href="#">Bollywood songs</a> |
        <a href="#">Bollywood songs</a> |
        <a href="#">Bollywood songs</a> |
        <a href="#">Bollywood songs</a> |
        <a href="#">Bollywood songs</a> |
        <a href="#">Bollywood songs</a> |

        </p>
    </div>   
  </div>
</div>
<div class="card-deck">

  <div class="card">
    <div class="card-body">
      <h5 class="card-title">New releases</h5>
      <p class="card-text">
        <a href="#">English songs</a> |
        <a href="#">English songs</a> |
        <a href="#">English songs</a> |
        <a href="#">English songs</a> |
        <a href="#">English songs</a> |
        <a href="#">English songs</a> |
        <a href="#">English songs</a> |
        <a href="#">English songs</a> |
        <a href="#">English songs</a> |
        <a href="#">English songs</a> |

        </p>
    </div>   
  </div>

  <div class="card">
    <div class="card-body">
      <h5 class="card-title">Treding songs</h5>
      <p class="card-text">
        <a href="#">Hanuman chalisa</a> |
        <a href="#">Hanuman chalisa</a> |
        <a href="#">Hanuman chalisa</a> |
        <a href="#">Hanuman chalisa</a> |
        <a href="#">Hanuman chalisa</a> |
        <a href="#">Hanuman chalisa</a> |
        <a href="#">Hanuman chalisa</a> |
        <a href="#">Hanuman chalisa</a> |
        <a href="#">Hanuman chalisa</a> |
        <a href="#">Hanuman chalisa</a> |

    </div>   
  </div>

  <div class="card">
    <div class="card-body">
      <h5 class="card-title">Treadings Album</h5>
      <p class="card-text">
        <a href="#">Happy Birthday</a> |
        <a href="#">Happy Birthday</a> |
        <a href="#">Happy Birthday</a> |
        <a href="#">Happy Birthday</a> |
        <a href="#">Happy Birthday</a> |
        <a href="#">Happy Birthday</a> |
        <a href="#">Happy Birthday</a> |
        <a href="#">Happy Birthday</a> |
        <a href="#">Happy Birthday</a> |
        <a href="#">Happy Birthday</a> |

    </div>   
  </div>

</div>
<hr>
<div>
  <p>
    Advertise on ganna.com  | Terms of use  |    Privacy Police  | Feedback    |  Report on issue   |  Partners   |   Sitemaps |   FAQ
  </p>
  <p>Gamma Ganna Ltd. 2020 | All right reserved</p>
</div>
</div>
 